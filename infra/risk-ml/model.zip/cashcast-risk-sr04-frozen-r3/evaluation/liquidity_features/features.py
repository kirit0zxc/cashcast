"""Запас ликвидности, регулярность и исторические просадки; только прошлые дни."""

import math
from collections import Counter, deque
from itertools import pairwise
from statistics import mean, median, pstdev

from evaluation.risk_candidate.features import LiquidityFeatures


class CashFeatures:
    @staticmethod
    def reserve(net, horizon):
        # Максимальная историческая просадка на любом отрезке не длиннее horizon.
        prefix, peaks, result = 0.0, deque([(0, 0.0)]), 0.0
        for index, value in enumerate(net, 1):
            prefix += value
            while peaks and peaks[0][0] < index - horizon:
                peaks.popleft()
            result = max(result, peaks[0][1] - prefix)
            while peaks and peaks[-1][1] <= prefix:
                peaks.pop()
            peaks.append((index, prefix))
        return result

    @classmethod
    def build(cls, history):
        if len(history) != 84:
            raise ValueError("Требуется 84 дня истории")
        if any((b.date - a.date).days != 1 for a, b in pairwise(history)):
            raise ValueError("История должна быть непрерывной")
        if any(day.incoming < 0 or day.outgoing < 0 for day in history):
            raise ValueError("Потоки должны быть неотрицательными")
        basic = LiquidityFeatures.build(history)
        result = {f"basic_{i}": value for i, value in enumerate(basic)}
        scale = max(100.0, mean(d.outgoing for d in history))
        last = history[-1]
        balance = last.balance / scale
        for window in (7, 14, 28, 56, 84):
            tail = history[-window:]
            incoming = [d.incoming / scale for d in tail]
            outgoing = [d.outgoing / scale for d in tail]
            balances = [d.balance / scale for d in tail]
            net = [a - b for a, b in zip(incoming, outgoing, strict=True)]
            result.update({f"net_{window}": sum(net), f"net_std_{window}": pstdev(net),
                           f"income_{window}": mean(incoming), f"expense_{window}": mean(outgoing),
                           f"income_median_{window}": median(incoming),
                           f"expense_max_{window}": max(outgoing),
                           f"balance_std_{window}": pstdev(balances),
                           f"balance_min_{window}": min(balances),
                           f"near_zero_{window}": sum(b < 3 for b in balances) / window,
                           f"income_days_{window}": sum(v > 0 for v in incoming) / window,
                           f"expense_days_{window}": sum(v > 0 for v in outgoing) / window,
                           f"net_negative_days_{window}": sum(v < 0 for v in net) / window,
                           f"drawdown_{window}": max(balances) - balance,
                           f"runway_{window}": balance / max(0.01, -mean(net)),
                           f"coverage_{window}": balance / max(0.01, sum(outgoing)),
                           f"largest_income_share_{window}": max(incoming) / max(0.01, sum(incoming)),
                           f"largest_expense_share_{window}": max(outgoing) / max(0.01, sum(outgoing))})
        for window in (7, 14, 28):
            for field in ("incoming", "outgoing"):
                recent = mean(getattr(d, field) for d in history[-window:]) / scale
                previous = mean(getattr(d, field) for d in history[-2 * window:-window]) / scale
                result[f"{field}_trend_{window}"] = recent - previous
                result[f"{field}_ratio_{window}"] = recent / max(0.01, previous)
        income_indices = [i for i, d in enumerate(history) if d.incoming > 0]
        gaps = [b - a for a, b in pairwise(income_indices)]
        since_income = 83 - income_indices[-1] if income_indices else 84
        typical_gap = median(gaps) if gaps else 84
        amounts = Counter(d.incoming for d in history if d.incoming > 0)
        result.update(income_count=len(income_indices), income_interval_median=typical_gap,
                      income_interval_std=pstdev(gaps) if gaps else 0,
                      income_lateness=since_income / max(1, typical_gap),
                      income_repeat_share=max(amounts.values(), default=0) / max(1, len(income_indices)),
                      day_sin=math.sin(2 * math.pi * last.date.day / 31),
                      day_cos=math.cos(2 * math.pi * last.date.day / 31))
        for field in ("incoming", "outgoing"):
            total = sum(getattr(d, field) for d in history)
            for weekday in range(7):
                result[f"{field}_weekday_{weekday}"] = sum(
                    getattr(d, field) for d in history if d.date.weekday() == weekday
                ) / max(100, total)
            for start, end in ((1, 10), (11, 20), (21, 31)):
                result[f"{field}_monthpart_{start}"] = sum(
                    getattr(d, field) for d in history if start <= d.date.day <= end
                ) / max(100, total)
        net = [(d.incoming - d.outgoing) / scale for d in history]
        for horizon in (7, 14, 28):
            reserve = cls.reserve(net, horizon)
            result[f"reserve_{horizon}"] = reserve
            result[f"reserve_margin_{horizon}"] = balance - reserve
            result[f"reserve_coverage_{horizon}"] = balance / max(0.01, reserve)
        if any(not math.isfinite(v) for v in result.values()):
            raise ValueError("Неконечный признак")
        return {key: max(-1e6, min(1e6, float(value))) for key, value in result.items()}
