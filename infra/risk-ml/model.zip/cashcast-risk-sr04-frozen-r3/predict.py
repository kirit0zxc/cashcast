"""Переносимый исследовательский запуск зафиксированной модели без переобучения."""

import argparse
import hashlib
import json
from datetime import date, timedelta
from pathlib import Path


class FrozenRisk:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.manifest = json.loads((self.root / "manifest.json").read_text("utf-8"))
        for relative, expected in self.manifest["sha256"].items():
            path = (self.root / relative).resolve()
            if not path.is_relative_to(self.root) or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                raise ValueError("PACKAGE_INTEGRITY_FAILED")
        self.config = json.loads((self.root / "model.json").read_text("utf-8"))

    @staticmethod
    def validate(value):
        from evaluation.real_data.datasets import Day

        if not isinstance(value, dict) or set(value) != {"as_of", "horizon_days", "history"}:
            raise ValueError("INVALID_INPUT_FIELDS")
        if type(value["horizon_days"]) is not int or value["horizon_days"] != 30:
            raise ValueError("UNSUPPORTED_HORIZON")
        if not isinstance(value["history"], list) or len(value["history"]) != 84:
            raise ValueError("REQUIRES_84_DAYS")
        as_of, days = date.fromisoformat(value["as_of"]), []
        for index, row in enumerate(value["history"]):
            if not isinstance(row, dict) or set(row) != {"date", "incoming", "outgoing", "balance"}:
                raise ValueError("INVALID_DAY_FIELDS")
            if any(type(row[key]) is not int or abs(row[key]) > 10**15
                   for key in ("incoming", "outgoing", "balance")):
                raise ValueError("MONEY_MUST_BE_INTEGER_MINOR_UNITS")
            if min(row["incoming"], row["outgoing"]) < 0:
                raise ValueError("NEGATIVE_FLOW")
            day = Day(date.fromisoformat(row["date"]), row["incoming"], row["outgoing"], row["balance"])
            if day.date != as_of - timedelta(days=83 - index):
                raise ValueError("HISTORY_DATE_BOUNDARY_FAILED")
            if days and day.balance != days[-1].balance + day.incoming - day.outgoing:
                raise ValueError("BALANCE_CHAIN_FAILED")
            days.append(day)
        if days[-1].balance < 0:
            raise ValueError("ALREADY_NEGATIVE_NOT_SUPPORTED")
        return days

    def predict(self, value):
        from catboost import CatBoostClassifier

        from evaluation.liquidity_features.features import CashFeatures

        days = self.validate(value)
        values = CashFeatures.build(days)
        if list(values) != self.config["feature_names"]:
            raise ValueError("FEATURE_SCHEMA_MISMATCH")
        model = CatBoostClassifier()
        model.load_model(str(self.root / "model.cbm"))
        score = float(model.predict_proba([list(values.values())])[0, 1])
        return {"model_version": self.config["version"], "as_of": value["as_of"], "horizon_days": 30,
                "risk_score": score, "alert_threshold": self.config["threshold"],
                "alert": score >= self.config["threshold"], "probability": None,
                "research_only": True, "production_eligible": False,
                "note": "Score не является откалиброванной вероятностью; планы и сценарии не поддержаны."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify", action="store_true")
    parser.add_argument("--input", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        runtime = FrozenRisk(Path(__file__).resolve().parent)
        if args.verify:
            result = {"verified": True, "model_version": runtime.config["version"],
                      "production_eligible": False}
        elif args.input:
            result = runtime.predict(json.loads(args.input.read_text("utf-8-sig")))
        else:
            parser.error("Нужно --verify или --input")
    except (ValueError, TypeError, KeyError):
        # Ошибочная строка выписки не должна попадать в консоль через текст исключения.
        raise SystemExit("INPUT_OR_PACKAGE_VALIDATION_FAILED") from None
    text = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    else:
        print(text)


if __name__ == "__main__":
    main()
